# 🌿 John Doe Landscaping

A full-stack web application for a solo landscaping business. Built with React, Express, and PostgreSQL.

## Features

**Public Website**
- Home, About, Services, and Contact pages
- Online quote request form with email confirmation

**Admin Dashboard** (login required)
- Job scheduler with calendar + list views
- Customer CRM with job history and notes
- Quote management with convert-to-job workflow
- Business analytics and revenue tracking
- Google Calendar integration
- Automated email notifications

## Tech Stack

- **Frontend:** React 18 + Tailwind CSS
- **Backend:** Node.js + Express
- **Database:** PostgreSQL
- **Auth:** JWT
- **Email:** Nodemailer
- **Calendar:** Google Calendar API

## Quick Start

### 1. Clone and Install

```bash
npm run install:all
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your database URL and credentials
```

### 3. Initialize Database

```bash
npm run db:init
```

### 4. Run Development

```bash
npm run dev
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

### 5. Production Build

```bash
npm run build
npm start
```

## Deployment on Replit

1. Import this repo into Replit
2. Add a PostgreSQL database in Replit's tools
3. Set environment variables in Replit Secrets
4. Run `npm run db:init` in the shell
5. Click "Run" — the app starts automatically

## Default Login

- **Email:** john@johndoelandscaping.com
- **Password:** changeme123

> ⚠️ Change the default password immediately after first login.

## API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/login | No | Login |
| GET | /api/auth/me | Yes | Current user |
| GET | /api/customers | Yes | List customers |
| POST | /api/customers | Yes | Create customer |
| GET | /api/customers/:id | Yes | Customer detail |
| PUT | /api/customers/:id | Yes | Update customer |
| DELETE | /api/customers/:id | Yes | Delete customer |
| POST | /api/customers/:id/notes | Yes | Add customer note |
| GET | /api/jobs | Yes | List jobs |
| POST | /api/jobs | Yes | Create job |
| GET | /api/jobs/:id | Yes | Job detail |
| PUT | /api/jobs/:id | Yes | Update job |
| PATCH | /api/jobs/:id/status | Yes | Update job status |
| DELETE | /api/jobs/:id | Yes | Delete job |
| POST | /api/jobs/:id/notes | Yes | Add job note |
| GET | /api/quotes | Yes | List quotes |
| POST | /api/quotes | No | Submit quote (public) |
| PUT | /api/quotes/:id | Yes | Update quote |
| POST | /api/quotes/:id/convert | Yes | Convert to job |
| DELETE | /api/quotes/:id | Yes | Delete quote |
| GET | /api/analytics/dashboard | Yes | Dashboard stats |
| GET | /api/google/auth-url | Yes | Google OAuth URL |
| GET | /api/google/callback | No | Google OAuth callback |

## Project Structure

```
├── client/                  # React frontend
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── components/      # Reusable components
│       ├── context/         # Auth context
│       ├── pages/           # Page components
│       └── utils/           # API helper
├── database/
│   ├── schema.sql           # Database schema
│   └── init.js              # Seed script
├── server/
│   ├── config/              # Database pool
│   ├── middleware/           # JWT auth
│   ├── routes/              # API routes
│   ├── utils/               # Email & Google Calendar
│   └── index.js             # Express app
├── .env.example
├── .replit
├── package.json
└── README.md
```

require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function initDB() {
  const client = await pool.connect();
  try {
    console.log('🌱 Initializing database...');

    // Run schema
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await client.query(schema);
    console.log('✅ Schema created successfully');

    // Seed owner account
    const email = process.env.OWNER_EMAIL || 'john@johndoelandscaping.com';
    const password = process.env.OWNER_PASSWORD || 'changeme123';
    const hash = await bcrypt.hash(password, 12);

    await client.query(
      `INSERT INTO users (email, password_hash, name)
       VALUES ($1, $2, 'John Doe')
       ON CONFLICT (email) DO UPDATE SET password_hash = $2`,
      [email, hash]
    );
    console.log(`✅ Owner account created: ${email}`);

    // Seed sample customers
    const customers = [
      ['Sarah', 'Johnson', 'sarah@email.com', '555-0101', '123 Maple St', 'Springfield', 'IL', '62701'],
      ['Mike', 'Williams', 'mike@email.com', '555-0102', '456 Oak Ave', 'Springfield', 'IL', '62702'],
      ['Emily', 'Davis', 'emily@email.com', '555-0103', '789 Pine Dr', 'Springfield', 'IL', '62703'],
    ];

    for (const c of customers) {
      await client.query(
        `INSERT INTO customers (first_name, last_name, email, phone, address, city, state, zip)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING`,
        c
      );
    }
    console.log('✅ Sample customers seeded');

    // Get customer IDs for jobs
    const { rows: custs } = await client.query('SELECT id, first_name FROM customers ORDER BY created_at LIMIT 3');

    if (custs.length >= 3) {
      const today = new Date();
      const jobs = [
        [custs[0].id, 'Weekly Lawn Mowing', 'Regular weekly mow and edge', custs[0].id, 'scheduled', new Date(today.getTime() + 86400000).toISOString().split('T')[0], '09:00', 60, 75.00],
        [custs[1].id, 'Hedge Trimming', 'Trim all front hedges', custs[1].id, 'scheduled', new Date(today.getTime() + 172800000).toISOString().split('T')[0], '10:00', 90, 120.00],
        [custs[2].id, 'Spring Cleanup', 'Full yard spring cleanup with mulching', custs[2].id, 'in_progress', today.toISOString().split('T')[0], '08:00', 180, 250.00],
      ];

      for (const j of jobs) {
        await client.query(
          `INSERT INTO jobs (customer_id, title, description, address, status, scheduled_date, scheduled_time, estimated_duration, price)
           SELECT $1, $2, $3, c.address, $5, $6, $7, $8, $9
           FROM customers c WHERE c.id = $4
           ON CONFLICT DO NOTHING`,
          j
        );
      }
      console.log('✅ Sample jobs seeded');
    }

    // Seed sample quotes
    const quotes = [
      ['Tom Brown', 'tom@email.com', '555-0201', '321 Elm St', 'Lawn Mowing', 'Looking for weekly mowing service', null, 'pending'],
      ['Lisa Chen', 'lisa@email.com', '555-0202', '654 Birch Ln', 'Landscaping Design', 'Want to redesign front yard', null, 'pending'],
    ];

    for (const q of quotes) {
      await client.query(
        `INSERT INTO quotes (customer_name, email, phone, address, service_type, description, preferred_date, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING`,
        q
      );
    }
    console.log('✅ Sample quotes seeded');

    console.log('\n🎉 Database initialized successfully!');
  } catch (err) {
    console.error('❌ Database initialization failed:', err.message);
  } finally {
    client.release();
    await pool.end();
  }
}

initDB();

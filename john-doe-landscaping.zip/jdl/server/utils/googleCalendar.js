const { google } = require('googleapis');

function getOAuth2Client() {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return null;
  }
  const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
  return oauth2Client;
}

async function addToGoogleCalendar(job, refreshToken) {
  const oauth2Client = getOAuth2Client();
  if (!oauth2Client || !refreshToken) {
    console.log('📅 [Google Calendar Skipped - Not configured]');
    return null;
  }

  oauth2Client.setCredentials({ refresh_token: refreshToken });
  const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

  const startDate = new Date(`${job.scheduled_date}T${job.scheduled_time || '09:00'}:00`);
  const endDate = new Date(startDate.getTime() + (job.estimated_duration || 60) * 60000);

  try {
    const event = await calendar.events.insert({
      calendarId: 'primary',
      resource: {
        summary: `🌿 ${job.title}`,
        description: `${job.description || ''}\n\nCustomer Job - John Doe Landscaping`,
        location: job.address || '',
        start: { dateTime: startDate.toISOString(), timeZone: 'America/Chicago' },
        end: { dateTime: endDate.toISOString(), timeZone: 'America/Chicago' },
        reminders: { useDefault: false, overrides: [{ method: 'popup', minutes: 60 }] },
      },
    });
    console.log(`📅 Google Calendar event created: ${event.data.id}`);
    return event.data.id;
  } catch (err) {
    console.error('📅 Google Calendar error:', err.message);
    return null;
  }
}

async function removeFromGoogleCalendar(eventId, refreshToken) {
  const oauth2Client = getOAuth2Client();
  if (!oauth2Client || !refreshToken || !eventId) return;

  oauth2Client.setCredentials({ refresh_token: refreshToken });
  const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

  try {
    await calendar.events.delete({ calendarId: 'primary', eventId });
    console.log(`📅 Google Calendar event removed: ${eventId}`);
  } catch (err) {
    console.error('📅 Google Calendar remove error:', err.message);
  }
}

function getAuthUrl() {
  const oauth2Client = getOAuth2Client();
  if (!oauth2Client) return null;
  return oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: ['https://www.googleapis.com/auth/calendar.events'],
    prompt: 'consent',
  });
}

async function getTokenFromCode(code) {
  const oauth2Client = getOAuth2Client();
  if (!oauth2Client) return null;
  const { tokens } = await oauth2Client.getToken(code);
  return tokens;
}

module.exports = { addToGoogleCalendar, removeFromGoogleCalendar, getAuthUrl, getTokenFromCode };

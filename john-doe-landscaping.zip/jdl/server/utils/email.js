const nodemailer = require('nodemailer');

let transporter = null;

function getTransporter() {
  if (!transporter && process.env.SMTP_HOST) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT) || 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  return transporter;
}

async function sendEmail({ to, subject, html }) {
  const t = getTransporter();
  if (!t) {
    console.log(`📧 [Email Skipped - No SMTP configured] To: ${to}, Subject: ${subject}`);
    return { skipped: true };
  }

  try {
    const info = await t.sendMail({
      from: `"John Doe Landscaping" <${process.env.EMAIL_FROM || process.env.SMTP_USER}>`,
      to,
      subject,
      html,
    });
    console.log(`📧 Email sent: ${info.messageId}`);
    return info;
  } catch (err) {
    console.error('📧 Email error:', err.message);
    return { error: err.message };
  }
}

async function sendQuoteConfirmation(quote) {
  return sendEmail({
    to: quote.email,
    subject: 'Quote Request Received - John Doe Landscaping',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2d5a27; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">🌿 John Doe Landscaping</h1>
        </div>
        <div style="padding: 30px; background: #fafaf5;">
          <h2 style="color: #2d5a27;">Thank You, ${quote.customer_name}!</h2>
          <p>We've received your quote request and will get back to you within 24 hours.</p>
          <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #2d5a27;">
            <p><strong>Service:</strong> ${quote.service_type || 'General'}</p>
            <p><strong>Address:</strong> ${quote.address || 'Not specified'}</p>
            <p><strong>Details:</strong> ${quote.description || 'None provided'}</p>
          </div>
          <p style="color: #666; margin-top: 20px;">— John Doe Landscaping</p>
        </div>
      </div>
    `,
  });
}

async function sendJobReminder(job, customer) {
  if (!customer?.email) return;
  return sendEmail({
    to: customer.email,
    subject: `Job Reminder: ${job.title} - John Doe Landscaping`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2d5a27; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">🌿 John Doe Landscaping</h1>
        </div>
        <div style="padding: 30px; background: #fafaf5;">
          <h2 style="color: #2d5a27;">Upcoming Job Reminder</h2>
          <p>Hi ${customer.first_name},</p>
          <p>Just a reminder about your upcoming service:</p>
          <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #2d5a27;">
            <p><strong>Service:</strong> ${job.title}</p>
            <p><strong>Date:</strong> ${job.scheduled_date}</p>
            <p><strong>Time:</strong> ${job.scheduled_time || 'TBD'}</p>
            <p><strong>Address:</strong> ${job.address || customer.address || 'On file'}</p>
          </div>
          <p style="color: #666; margin-top: 20px;">— John Doe Landscaping</p>
        </div>
      </div>
    `,
  });
}

module.exports = { sendEmail, sendQuoteConfirmation, sendJobReminder };

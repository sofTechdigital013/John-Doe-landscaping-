const router = require('express').Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');
const { sendQuoteConfirmation } = require('../utils/email');

// GET /api/quotes (protected)
router.get('/', auth, async (req, res) => {
  try {
    const { status } = req.query;
    let query = 'SELECT * FROM quotes';
    const params = [];
    if (status) {
      query += ' WHERE status = $1';
      params.push(status);
    }
    query += ' ORDER BY created_at DESC';
    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/quotes/:id (protected)
router.get('/:id', auth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM quotes WHERE id = $1', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Quote not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/quotes (public - for quote request form)
router.post('/', async (req, res) => {
  try {
    const { customer_name, email, phone, address, service_type, description, preferred_date } = req.body;
    if (!customer_name || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
    }

    const { rows } = await pool.query(
      `INSERT INTO quotes (customer_name, email, phone, address, service_type, description, preferred_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [customer_name, email, phone, address, service_type, description, preferred_date || null]
    );

    // Send confirmation email
    sendQuoteConfirmation(rows[0]);

    res.status(201).json({ message: 'Quote request submitted successfully!', id: rows[0].id });
  } catch (err) {
    console.error('Create quote error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/quotes/:id (protected)
router.put('/:id', auth, async (req, res) => {
  try {
    const { status, estimated_price, admin_notes } = req.body;
    const { rows } = await pool.query(
      `UPDATE quotes SET status=$1, estimated_price=$2, admin_notes=$3, updated_at=NOW()
       WHERE id=$4 RETURNING *`,
      [status, estimated_price, admin_notes, req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Quote not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/quotes/:id/convert (protected - convert to job)
router.post('/:id/convert', auth, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows: quotes } = await client.query('SELECT * FROM quotes WHERE id = $1', [req.params.id]);
    if (quotes.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Quote not found' });
    }
    const quote = quotes[0];

    // Create or find customer
    const nameParts = quote.customer_name.trim().split(/\s+/);
    const firstName = nameParts[0];
    const lastName = nameParts.slice(1).join(' ') || 'Unknown';

    let customerId;
    const { rows: existing } = await client.query(
      'SELECT id FROM customers WHERE email = $1',
      [quote.email]
    );

    if (existing.length > 0) {
      customerId = existing[0].id;
    } else {
      const { rows: newCust } = await client.query(
        `INSERT INTO customers (first_name, last_name, email, phone, address)
         VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [firstName, lastName, quote.email, quote.phone, quote.address]
      );
      customerId = newCust[0].id;
    }

    // Create job from quote
    const { scheduled_date, scheduled_time, price } = req.body;
    const { rows: jobs } = await client.query(
      `INSERT INTO jobs (customer_id, title, description, address, scheduled_date, scheduled_time, price, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'scheduled') RETURNING *`,
      [
        customerId,
        quote.service_type || 'Service from Quote',
        quote.description,
        quote.address,
        scheduled_date || quote.preferred_date,
        scheduled_time,
        price || quote.estimated_price,
      ]
    );

    // Update quote status
    await client.query("UPDATE quotes SET status = 'converted', updated_at = NOW() WHERE id = $1", [req.params.id]);

    await client.query('COMMIT');
    res.json({ job: jobs[0], customer_id: customerId });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Convert quote error:', err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// DELETE /api/quotes/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    await pool.query('DELETE FROM quotes WHERE id = $1', [req.params.id]);
    res.json({ message: 'Quote deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

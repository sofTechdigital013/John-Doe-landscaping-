const router = require('express').Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// GET /api/customers
router.get('/', auth, async (req, res) => {
  try {
    const { search } = req.query;
    let query = `
      SELECT c.*,
        (SELECT COUNT(*) FROM jobs j WHERE j.customer_id = c.id) as job_count,
        (SELECT COALESCE(SUM(j.price), 0) FROM jobs j WHERE j.customer_id = c.id AND j.status = 'completed') as total_revenue
      FROM customers c
    `;
    const params = [];

    if (search) {
      query += ` WHERE LOWER(c.first_name || ' ' || c.last_name) LIKE $1 OR LOWER(c.email) LIKE $1 OR c.phone LIKE $1`;
      params.push(`%${search.toLowerCase()}%`);
    }

    query += ' ORDER BY c.created_at DESC';
    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    console.error('Get customers error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/customers/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const { rows: customers } = await pool.query('SELECT * FROM customers WHERE id = $1', [req.params.id]);
    if (customers.length === 0) return res.status(404).json({ error: 'Customer not found' });

    const { rows: jobs } = await pool.query(
      'SELECT * FROM jobs WHERE customer_id = $1 ORDER BY scheduled_date DESC',
      [req.params.id]
    );

    const { rows: notes } = await pool.query(
      'SELECT * FROM notes WHERE customer_id = $1 ORDER BY created_at DESC',
      [req.params.id]
    );

    res.json({ ...customers[0], jobs, notes });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/customers
router.post('/', auth, async (req, res) => {
  try {
    const { first_name, last_name, email, phone, address, city, state, zip } = req.body;
    if (!first_name || !last_name) {
      return res.status(400).json({ error: 'First and last name required' });
    }

    const { rows } = await pool.query(
      `INSERT INTO customers (first_name, last_name, email, phone, address, city, state, zip)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [first_name, last_name, email, phone, address, city, state, zip]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/customers/:id
router.put('/:id', auth, async (req, res) => {
  try {
    const { first_name, last_name, email, phone, address, city, state, zip } = req.body;
    const { rows } = await pool.query(
      `UPDATE customers SET first_name=$1, last_name=$2, email=$3, phone=$4,
       address=$5, city=$6, state=$7, zip=$8, updated_at=NOW()
       WHERE id=$9 RETURNING *`,
      [first_name, last_name, email, phone, address, city, state, zip, req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Customer not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/customers/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    await pool.query('DELETE FROM customers WHERE id = $1', [req.params.id]);
    res.json({ message: 'Customer deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/customers/:id/notes
router.post('/:id/notes', auth, async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ error: 'Note content required' });

    const { rows } = await pool.query(
      'INSERT INTO notes (customer_id, content) VALUES ($1, $2) RETURNING *',
      [req.params.id, content]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

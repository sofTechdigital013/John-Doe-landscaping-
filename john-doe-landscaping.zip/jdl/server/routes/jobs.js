const router = require('express').Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');
const { addToGoogleCalendar } = require('../utils/googleCalendar');
const { sendJobReminder } = require('../utils/email');

// GET /api/jobs
router.get('/', auth, async (req, res) => {
  try {
    const { status, month, year } = req.query;
    let query = `
      SELECT j.*, c.first_name || ' ' || c.last_name as customer_name, c.phone as customer_phone, c.email as customer_email
      FROM jobs j LEFT JOIN customers c ON j.customer_id = c.id
    `;
    const conditions = [];
    const params = [];

    if (status) {
      params.push(status);
      conditions.push(`j.status = $${params.length}`);
    }
    if (month && year) {
      params.push(parseInt(year), parseInt(month));
      conditions.push(`EXTRACT(YEAR FROM j.scheduled_date) = $${params.length - 1}`);
      conditions.push(`EXTRACT(MONTH FROM j.scheduled_date) = $${params.length}`);
    }

    if (conditions.length) query += ' WHERE ' + conditions.join(' AND ');
    query += ' ORDER BY j.scheduled_date ASC, j.scheduled_time ASC';

    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    console.error('Get jobs error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/jobs/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT j.*, c.first_name || ' ' || c.last_name as customer_name,
       c.phone as customer_phone, c.email as customer_email, c.address as customer_address
       FROM jobs j LEFT JOIN customers c ON j.customer_id = c.id WHERE j.id = $1`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Job not found' });

    const { rows: notes } = await pool.query(
      'SELECT * FROM notes WHERE job_id = $1 ORDER BY created_at DESC',
      [req.params.id]
    );
    res.json({ ...rows[0], notes });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/jobs
router.post('/', auth, async (req, res) => {
  try {
    const { customer_id, title, description, address, status, scheduled_date, scheduled_time, estimated_duration, price } = req.body;
    if (!title) return res.status(400).json({ error: 'Job title required' });

    const { rows } = await pool.query(
      `INSERT INTO jobs (customer_id, title, description, address, status, scheduled_date, scheduled_time, estimated_duration, price)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [customer_id, title, description, address, status || 'scheduled', scheduled_date, scheduled_time, estimated_duration, price]
    );

    const job = rows[0];

    // Add to Google Calendar
    const { rows: users } = await pool.query('SELECT google_refresh_token FROM users WHERE id = $1', [req.user.id]);
    if (users[0]?.google_refresh_token && job.scheduled_date) {
      const eventId = await addToGoogleCalendar(job, users[0].google_refresh_token);
      if (eventId) {
        await pool.query('UPDATE jobs SET google_event_id = $1 WHERE id = $2', [eventId, job.id]);
        job.google_event_id = eventId;
      }
    }

    // Send reminder email
    if (customer_id && job.scheduled_date) {
      const { rows: custs } = await pool.query('SELECT * FROM customers WHERE id = $1', [customer_id]);
      if (custs[0]) sendJobReminder(job, custs[0]);
    }

    res.status(201).json(job);
  } catch (err) {
    console.error('Create job error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/jobs/:id
router.put('/:id', auth, async (req, res) => {
  try {
    const { customer_id, title, description, address, status, scheduled_date, scheduled_time, estimated_duration, price } = req.body;
    const { rows } = await pool.query(
      `UPDATE jobs SET customer_id=$1, title=$2, description=$3, address=$4, status=$5,
       scheduled_date=$6, scheduled_time=$7, estimated_duration=$8, price=$9, updated_at=NOW()
       WHERE id=$10 RETURNING *`,
      [customer_id, title, description, address, status, scheduled_date, scheduled_time, estimated_duration, price, req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Job not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PATCH /api/jobs/:id/status
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    if (!['scheduled', 'in_progress', 'completed', 'cancelled'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    const { rows } = await pool.query(
      'UPDATE jobs SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
      [status, req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Job not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/jobs/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    await pool.query('DELETE FROM jobs WHERE id = $1', [req.params.id]);
    res.json({ message: 'Job deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/jobs/:id/notes
router.post('/:id/notes', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const { rows } = await pool.query(
      'INSERT INTO notes (job_id, content) VALUES ($1, $2) RETURNING *',
      [req.params.id, content]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

const router = require('express').Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');
const { getAuthUrl, getTokenFromCode } = require('../utils/googleCalendar');

// GET /api/google/auth-url
router.get('/auth-url', auth, async (req, res) => {
  const url = getAuthUrl();
  if (!url) return res.status(400).json({ error: 'Google Calendar not configured' });
  res.json({ url });
});

// GET /api/google/callback
router.get('/callback', async (req, res) => {
  try {
    const { code } = req.query;
    if (!code) return res.status(400).send('No authorization code');

    const tokens = await getTokenFromCode(code);
    if (tokens?.refresh_token) {
      await pool.query(
        'UPDATE users SET google_refresh_token = $1 WHERE id = (SELECT id FROM users LIMIT 1)',
        [tokens.refresh_token]
      );
    }

    res.send('<html><body><h2>Google Calendar connected! You can close this window.</h2><script>window.close();</script></body></html>');
  } catch (err) {
    console.error('Google callback error:', err);
    res.status(500).send('Failed to connect Google Calendar');
  }
});

// DELETE /api/google/disconnect
router.delete('/disconnect', auth, async (req, res) => {
  try {
    await pool.query('UPDATE users SET google_refresh_token = NULL WHERE id = $1', [req.user.id]);
    res.json({ message: 'Google Calendar disconnected' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

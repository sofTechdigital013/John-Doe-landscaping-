const router = require('express').Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// GET /api/analytics/dashboard
router.get('/dashboard', auth, async (req, res) => {
  try {
    const [
      totalCustomers,
      totalJobs,
      completedJobs,
      activeJobs,
      pendingQuotes,
      revenue,
      recentJobs,
      monthlyRevenue,
    ] = await Promise.all([
      pool.query('SELECT COUNT(*) as count FROM customers'),
      pool.query('SELECT COUNT(*) as count FROM jobs'),
      pool.query("SELECT COUNT(*) as count FROM jobs WHERE status = 'completed'"),
      pool.query("SELECT COUNT(*) as count FROM jobs WHERE status IN ('scheduled', 'in_progress')"),
      pool.query("SELECT COUNT(*) as count FROM quotes WHERE status = 'pending'"),
      pool.query("SELECT COALESCE(SUM(price), 0) as total FROM jobs WHERE status = 'completed'"),
      pool.query(`
        SELECT j.*, c.first_name || ' ' || c.last_name as customer_name
        FROM jobs j LEFT JOIN customers c ON j.customer_id = c.id
        ORDER BY j.scheduled_date DESC LIMIT 5
      `),
      pool.query(`
        SELECT
          TO_CHAR(scheduled_date, 'YYYY-MM') as month,
          COUNT(*) as jobs_count,
          COALESCE(SUM(price), 0) as revenue
        FROM jobs
        WHERE status = 'completed' AND scheduled_date >= NOW() - INTERVAL '6 months'
        GROUP BY TO_CHAR(scheduled_date, 'YYYY-MM')
        ORDER BY month ASC
      `),
    ]);

    res.json({
      totalCustomers: parseInt(totalCustomers.rows[0].count),
      totalJobs: parseInt(totalJobs.rows[0].count),
      completedJobs: parseInt(completedJobs.rows[0].count),
      activeJobs: parseInt(activeJobs.rows[0].count),
      pendingQuotes: parseInt(pendingQuotes.rows[0].count),
      totalRevenue: parseFloat(revenue.rows[0].total),
      recentJobs: recentJobs.rows,
      monthlyRevenue: monthlyRevenue.rows,
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

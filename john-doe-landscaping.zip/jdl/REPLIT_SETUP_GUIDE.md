# 🌿 John Doe Landscaping — Replit Setup Guide

A complete beginner-friendly walkthrough to get your app live on Replit.

---

## Step 1: Create a Replit Account and Import the Project

1. Go to **https://replit.com** in your browser.
2. Click **Sign Up** in the top right corner. You can sign up with Google, GitHub, or an email address.
3. Once you're logged in, you'll see your Replit dashboard (called "Home").
4. Click the **+ Create Repl** button (blue button, usually top left area).
5. In the popup that appears, you have two options to get the code into Replit:

### Option A: Import from GitHub (recommended if you pushed the code there)
   - Click the **Import from GitHub** tab at the top of the popup.
   - Paste your GitHub repository URL.
   - Click **Import from GitHub**.

### Option B: Upload the files manually
   - In the popup, select **Node.js** as the template.
   - Give it a name like `john-doe-landscaping`.
   - Click **Create Repl**.
   - Once the Repl opens, you'll see a file tree on the left side. **Delete** the default files that Replit created (like `index.js`).
   - Now drag and drop the entire `john-doe-landscaping` project folder contents into the file panel on the left. Make sure the folder structure looks like this:
     ```
     client/
     database/
     server/
     .env.example
     .replit
     package.json
     README.md
     replit.nix
     ```

6. You should now see all the project files in the left sidebar of Replit. Take a moment to make sure the folder structure looks right — `client/`, `server/`, and `database/` should be at the top level.

---

## Step 2: Add a PostgreSQL Database

Your app needs a database to store customers, jobs, and quotes. Replit makes this easy.

1. In your Repl, look at the left sidebar. You'll see icons for different tools.
2. Click the **Tools** icon (it looks like a wrench or puzzle piece, near the bottom of the sidebar).
3. Search for **PostgreSQL** or **Database**.
4. Click **PostgreSQL** to add it to your Repl.
5. Replit will automatically create a database and set a `DATABASE_URL` environment variable for you. You'll see a database panel open showing your connection info.
6. **Important:** Copy the `DATABASE_URL` value — you'll need it in the next step. It will look something like:
   ```
   postgresql://username:password@hostname:5432/database_name
   ```

> **Note:** If you don't see PostgreSQL in the tools, you may need a Replit paid plan (Core or higher). The free plan has limited database support. As an alternative, you can use a free PostgreSQL database from **https://neon.tech** or **https://supabase.com** — both give you a `DATABASE_URL` you can use.

---

## Step 3: Set Up Environment Variables (Secrets)

Environment variables are like private settings for your app — things like passwords and API keys that you don't want anyone else to see.

1. In the left sidebar of your Repl, click the **Tools** icon again.
2. Search for and click **Secrets** (it has a lock icon).
3. You need to add the following secrets one at a time. For each one, click **+ New Secret**, type the **Key** (the name on the left), and the **Value** (what goes on the right), then click **Add Secret**.

### Required Secrets

| Key | Value | What It Does |
|-----|-------|-------------|
| `DATABASE_URL` | The URL from Step 2 (paste the one Replit gave you) | Connects to your database |
| `JWT_SECRET` | Type any long random string, like `my-super-secret-key-jdl-2026-xyz` | Secures your login sessions |
| `NODE_ENV` | `production` | Tells the app to serve the built frontend |
| `OWNER_EMAIL` | `john@johndoelandscaping.com` (or whatever email you want to log in with) | Your dashboard login email |
| `OWNER_PASSWORD` | Pick a strong password you'll remember | Your dashboard login password |

### Optional Secrets (add these later if you want email and Google Calendar)

| Key | Value | What It Does |
|-----|-------|-------------|
| `SMTP_HOST` | `smtp.gmail.com` (if using Gmail) | Email server address |
| `SMTP_PORT` | `587` | Email server port |
| `SMTP_USER` | Your Gmail address | Email login |
| `SMTP_PASS` | A Gmail App Password (not your regular password) | Email authentication |
| `EMAIL_FROM` | `noreply@johndoelandscaping.com` | The "from" address on emails |
| `GOOGLE_CLIENT_ID` | From Google Cloud Console | For Google Calendar sync |
| `GOOGLE_CLIENT_SECRET` | From Google Cloud Console | For Google Calendar sync |
| `GOOGLE_REDIRECT_URI` | `https://your-repl-name.repl.co/api/google/callback` | Google Calendar callback URL |

> **Don't worry about the optional ones right now.** The app works perfectly fine without email and Google Calendar. You can always add them later.

> **Gmail App Password tip:** If you want to enable emails later, you'll need to go to your Google Account → Security → 2-Step Verification → App Passwords, and generate a password specifically for this app. Regular Gmail passwords won't work.

---

## Step 4: Initialize the Database and Build the App

Now you need to run a few commands to set everything up. This is where you tell the database what tables to create and build the frontend.

1. In your Repl, find the **Shell** tab. It's usually at the bottom of the screen, next to "Console". If you don't see it:
   - Click the **Tools** icon in the left sidebar
   - Search for **Shell**
   - Click it to open a terminal

2. The Shell is like a command line — you type commands and press Enter. Run these commands **one at a time**, waiting for each to finish before running the next:

### Command 1: Install all dependencies
```bash
npm install
```
> **What this does:** Downloads all the code libraries the app needs (Express, React, etc). You'll see a lot of text scroll by — that's normal. Wait until you see it finish and the cursor comes back.
>
> **This might take 2-3 minutes.** Be patient.

### Command 2: Build the frontend
```bash
npm run build
```
> **What this does:** Compiles all the React code into optimized files that the server can serve to visitors. You'll see messages about creating an optimized production build.
>
> **This might take 1-2 minutes.** When it's done, you'll see "Compiled successfully" or similar.

### Command 3: Initialize the database
```bash
npm run db:init
```
> **What this does:** Creates all the database tables (customers, jobs, quotes, etc.) and sets up your owner login account with the email and password you entered in the Secrets.
>
> **You should see output like:**
> ```
> 🌱 Initializing database...
> ✅ Schema created successfully
> ✅ Owner account created: john@johndoelandscaping.com
> ✅ Sample customers seeded
> ✅ Sample jobs seeded
> ✅ Sample quotes seeded
> 🎉 Database initialized successfully!
> ```
>
> **If you see an error about DATABASE_URL:** Go back to Step 3 and make sure the DATABASE_URL secret is set correctly.

---

## Step 5: Run the App!

1. Click the big green **Run** button at the top of the Replit screen.
2. Wait a few seconds. You should see in the Console:
   ```
   🌿 John Doe Landscaping Server
      Running on port 5000
      Environment: production
   ```
3. A **Webview** panel will appear showing your live website! You'll see the John Doe Landscaping homepage.
4. If the Webview doesn't appear automatically, look for a panel labeled "Webview" or click the **Open in new tab** icon to see your site in a full browser window.

---

## Step 6: Get Your Public URL

1. At the top of the Webview panel, you'll see a URL that looks something like:
   ```
   https://john-doe-landscaping.your-username.repl.co
   ```
2. **This is your live website URL!** Anyone can visit it.
3. Copy this URL — this is what you'd share with customers or put on business cards.

---

## Step 7: Log Into the Dashboard

1. Go to your site URL and add `/login` at the end:
   ```
   https://your-repl-url.repl.co/login
   ```
2. Enter the **OWNER_EMAIL** and **OWNER_PASSWORD** you set in Step 3.
3. You'll be taken to the Admin Dashboard where you can:
   - View your business overview and stats
   - Manage jobs (calendar and list view)
   - Manage customers
   - Review and convert quote requests
   - Update job statuses from your phone while in the field

---

## Troubleshooting

### "Cannot connect to database" or DATABASE_URL error
- Go to Secrets (lock icon in left sidebar) and make sure `DATABASE_URL` is set
- The value should start with `postgresql://`
- Try running `npm run db:init` again in the Shell

### Page shows "Cannot GET /" or blank screen
- Make sure you ran `npm run build` (Step 4, Command 2)
- Make sure `NODE_ENV` is set to `production` in Secrets
- Click the **Run** button again

### Login doesn't work
- Run `npm run db:init` again to recreate your account
- Double-check your `OWNER_EMAIL` and `OWNER_PASSWORD` in Secrets match what you're typing
- Passwords are case-sensitive

### Site is slow to load the first time
- This is normal on Replit's free tier. The server "sleeps" when nobody visits for a while and takes a few seconds to wake up
- On a paid Replit plan, you can enable "Always On" to keep it running

### Shell commands aren't working
- Make sure you're in the Shell tab, not the Console tab
- If you see "command not found" for npm, try refreshing the Replit page

### I want to change my login password
- Update the `OWNER_PASSWORD` secret in the Secrets panel
- Run `npm run db:init` again in the Shell
- This will update your password without losing any data

---

## What's Next?

Once your app is running, here are some things you can do:

- **Bookmark the dashboard** on your phone's home screen for quick field access
- **Submit a test quote** from the public website to see it appear in your dashboard
- **Create your first real customer and job** from the dashboard
- **Set up email notifications** by adding the SMTP secrets (see Step 3 optional secrets)
- **Connect Google Calendar** from Dashboard → Settings (requires Google Cloud Console setup)
- **Get a custom domain** — Replit lets you connect your own domain name (like johndoelandscaping.com) in the Repl settings under "Custom Domains"

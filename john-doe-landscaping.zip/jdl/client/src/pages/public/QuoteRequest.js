import { useState } from 'react';
import { api } from '../../utils/api';

const serviceTypes = [
  'Lawn Mowing', 'Tree & Hedge Trimming', 'Garden Design', 'Seasonal Cleanup',
  'Irrigation', 'Hardscaping', 'Lawn Treatment', 'Pressure Washing', 'Other',
];

export default function QuoteRequest() {
  const [form, setForm] = useState({
    customer_name: '', email: '', phone: '', address: '',
    service_type: '', description: '', preferred_date: '',
  });
  const [status, setStatus] = useState(null); // null | 'sending' | 'success' | 'error'
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('sending');
    setError('');
    try {
      await api.post('/quotes', form);
      setStatus('success');
      setForm({ customer_name: '', email: '', phone: '', address: '', service_type: '', description: '', preferred_date: '' });
    } catch (err) {
      setError(err.message);
      setStatus('error');
    }
  };

  const handleChange = (e) => {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }));
  };

  if (status === 'success') {
    return (
      <div className="fade-in">
        <section className="bg-gradient-to-br from-forest-700 to-forest-900 text-white py-16 sm:py-20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <h1 className="text-4xl sm:text-5xl mb-4">Request a Quote</h1>
          </div>
        </section>
        <div className="max-w-lg mx-auto px-4 py-20 text-center">
          <div className="text-6xl mb-4">✅</div>
          <h2 className="text-2xl text-forest-800 mb-3">Quote Request Submitted!</h2>
          <p className="text-bark-500 mb-6">Thank you! I'll review your request and get back to you within 24 hours.</p>
          <button onClick={() => setStatus(null)} className="px-6 py-3 bg-forest-600 text-white rounded-lg font-semibold hover:bg-forest-700 transition-colors">
            Submit Another Request
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <section className="bg-gradient-to-br from-forest-700 to-forest-900 text-white py-16 sm:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h1 className="text-4xl sm:text-5xl mb-4">Request a Quote</h1>
          <p className="text-forest-200 text-lg">Fill out the form below and I'll get back to you within 24 hours.</p>
        </div>
      </section>

      <section className="max-w-2xl mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white border border-forest-100 rounded-xl p-6 sm:p-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-bark-700 mb-1">Full Name *</label>
                <input name="customer_name" value={form.customer_name} onChange={handleChange} required
                  className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="John Smith" />
              </div>
              <div>
                <label className="block text-sm font-medium text-bark-700 mb-1">Email *</label>
                <input name="email" type="email" value={form.email} onChange={handleChange} required
                  className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="john@example.com" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-bark-700 mb-1">Phone</label>
                <input name="phone" value={form.phone} onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="(555) 123-4567" />
              </div>
              <div>
                <label className="block text-sm font-medium text-bark-700 mb-1">Preferred Date</label>
                <input name="preferred_date" type="date" value={form.preferred_date} onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-bark-700 mb-1">Property Address</label>
              <input name="address" value={form.address} onChange={handleChange}
                className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="123 Main St, Springfield, IL" />
            </div>

            <div>
              <label className="block text-sm font-medium text-bark-700 mb-1">Service Type</label>
              <select name="service_type" value={form.service_type} onChange={handleChange}
                className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm bg-white">
                <option value="">Select a service...</option>
                {serviceTypes.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-bark-700 mb-1">Project Details</label>
              <textarea name="description" value={form.description} onChange={handleChange} rows={4}
                className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm resize-none"
                placeholder="Tell me about your project — yard size, specific needs, budget range..."></textarea>
            </div>

            <button type="submit" disabled={status === 'sending'}
              className="w-full py-3 bg-forest-600 text-white font-semibold rounded-lg hover:bg-forest-700 transition-colors disabled:opacity-60">
              {status === 'sending' ? 'Submitting...' : 'Submit Quote Request'}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}

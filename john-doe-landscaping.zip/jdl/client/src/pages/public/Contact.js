import { Link } from 'react-router-dom';

export default function Contact() {
  return (
    <div className="fade-in">
      <section className="bg-gradient-to-br from-forest-700 to-forest-900 text-white py-16 sm:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h1 className="text-4xl sm:text-5xl mb-4">Contact Us</h1>
          <p className="text-forest-200 text-lg">Get in touch — I'd love to hear from you.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl text-forest-800 mb-6">Get In Touch</h2>
            <div className="space-y-6">
              {[
                { icon: '📍', label: 'Address', value: 'Springfield, IL 62701' },
                { icon: '📞', label: 'Phone', value: '(555) 123-4567', href: 'tel:5551234567' },
                { icon: '📧', label: 'Email', value: 'john@johndoelandscaping.com', href: 'mailto:john@johndoelandscaping.com' },
              ].map(item => (
                <div key={item.label} className="flex items-start gap-4">
                  <span className="text-2xl mt-0.5">{item.icon}</span>
                  <div>
                    <div className="text-sm text-bark-400 font-medium">{item.label}</div>
                    {item.href ? (
                      <a href={item.href} className="text-forest-700 font-medium hover:text-forest-800">{item.value}</a>
                    ) : (
                      <div className="text-forest-700 font-medium">{item.value}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-forest-50 rounded-xl">
              <h3 className="font-display text-lg text-forest-800 mb-2">Business Hours</h3>
              <div className="space-y-1 text-sm text-bark-600">
                <div className="flex justify-between"><span>Monday – Friday</span><span className="font-medium">7:00 AM – 6:00 PM</span></div>
                <div className="flex justify-between"><span>Saturday</span><span className="font-medium">8:00 AM – 4:00 PM</span></div>
                <div className="flex justify-between"><span>Sunday</span><span className="text-bark-400">Closed</span></div>
              </div>
            </div>
          </div>

          <div className="bg-white border border-forest-100 rounded-xl p-6 sm:p-8">
            <h2 className="text-2xl text-forest-800 mb-2">Quick Quote</h2>
            <p className="text-sm text-bark-400 mb-6">For a detailed quote, use our <Link to="/quote" className="text-forest-600 underline">quote request form</Link>.</p>
            <div className="bg-bark-50 rounded-xl p-8 text-center">
              <div className="text-5xl mb-4">📞</div>
              <h3 className="font-display text-xl text-forest-800 mb-2">Prefer to Call?</h3>
              <p className="text-bark-500 text-sm mb-4">I'm happy to chat about your project over the phone.</p>
              <a href="tel:5551234567"
                className="inline-block px-6 py-3 bg-forest-600 text-white font-semibold rounded-lg hover:bg-forest-700 transition-colors">
                Call (555) 123-4567
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

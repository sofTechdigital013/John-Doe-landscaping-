import { Link } from 'react-router-dom';

const services = [
  { icon: '🌿', title: 'Lawn Mowing', desc: 'Weekly and bi-weekly mowing, edging, and trimming to keep your lawn pristine.' },
  { icon: '🌳', title: 'Tree & Hedge Trimming', desc: 'Expert pruning and shaping to enhance your property\'s curb appeal.' },
  { icon: '🌸', title: 'Garden Design', desc: 'Custom flower beds, planters, and landscape design for every season.' },
  { icon: '🍂', title: 'Seasonal Cleanup', desc: 'Spring and fall cleanups including leaf removal, mulching, and prep.' },
  { icon: '💧', title: 'Irrigation', desc: 'Sprinkler system installation, repair, and seasonal maintenance.' },
  { icon: '🪨', title: 'Hardscaping', desc: 'Patios, walkways, retaining walls, and decorative stone features.' },
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-forest-800 via-forest-700 to-forest-900 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 border border-forest-400 rounded-full"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 border border-forest-400 rounded-full"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border border-forest-400 rounded-full"></div>
        </div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-20 sm:py-32">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-forest-600/40 backdrop-blur-sm rounded-full px-4 py-1.5 mb-6">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              <span className="text-sm font-medium text-forest-100">Now Booking Spring 2026</span>
            </div>
            <h1 className="text-4xl sm:text-6xl leading-tight mb-6">
              Your Lawn,<br/>
              <span className="text-sand-300">Our Passion.</span>
            </h1>
            <p className="text-lg text-forest-200 mb-8 max-w-lg leading-relaxed">
              Professional landscaping services in Springfield. From weekly mowing to complete landscape transformations, I deliver quality work with a personal touch.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link to="/quote"
                className="px-7 py-3.5 bg-sand-400 text-forest-900 font-semibold rounded-lg hover:bg-sand-300 transition-all shadow-lg text-center">
                Get a Free Quote
              </Link>
              <Link to="/services"
                className="px-7 py-3.5 border-2 border-forest-400 text-white font-semibold rounded-lg hover:bg-forest-600/30 transition-all text-center">
                View Services
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-bark-50 border-b border-bark-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
          <div className="grid grid-cols-3 gap-4 text-center">
            {[['10+', 'Years Experience'], ['500+', 'Jobs Completed'], ['100%', 'Satisfaction']].map(([num, label]) => (
              <div key={label}>
                <div className="text-2xl sm:text-3xl font-display text-forest-700">{num}</div>
                <div className="text-xs sm:text-sm text-bark-500 mt-1">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services grid */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16 sm:py-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl text-forest-800 mb-3">Our Services</h2>
          <p className="text-bark-500 max-w-md mx-auto">Everything you need to keep your outdoor spaces beautiful year-round.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map(s => (
            <div key={s.title}
              className="group p-6 bg-white border border-forest-100 rounded-xl hover:border-forest-300 hover:shadow-lg transition-all">
              <span className="text-3xl block mb-3">{s.icon}</span>
              <h3 className="text-lg text-forest-800 mb-2 font-display">{s.title}</h3>
              <p className="text-sm text-bark-500 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link to="/services" className="text-forest-600 font-semibold hover:text-forest-800 transition-colors">
            View all services →
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-bark-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16 sm:py-20 text-center">
          <h2 className="text-3xl sm:text-4xl text-forest-800 mb-4">Ready to Transform Your Yard?</h2>
          <p className="text-bark-500 mb-8 max-w-md mx-auto">Get a free, no-obligation quote today. I'll personally assess your property and provide a detailed estimate.</p>
          <Link to="/quote"
            className="inline-block px-8 py-3.5 bg-forest-600 text-white font-semibold rounded-lg hover:bg-forest-700 transition-colors shadow-md">
            Request a Free Quote
          </Link>
        </div>
      </section>
    </div>
  );
}

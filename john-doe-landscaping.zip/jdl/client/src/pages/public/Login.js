import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Link, Navigate } from 'react-router-dom';

export default function Login() {
  const { user, login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await login(email, password);
    } catch (err) {
      setError(err.message || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-forest-800 via-forest-700 to-forest-900 flex items-center justify-center px-4">
      <div className="w-full max-w-sm fade-in">
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-forest-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 3c-1.5 3-4 5-7 6 1 2 2 5 2 8h10c0-3 1-6 2-8-3-1-5.5-3-7-6z"/>
              <path d="M12 21v-8"/>
            </svg>
          </div>
          <h1 className="text-2xl text-white font-display">JD Landscaping</h1>
          <p className="text-forest-300 text-sm mt-1">Admin Dashboard</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-xl">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">{error}</div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-bark-700 mb-1">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm"
                placeholder="john@johndoelandscaping.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-bark-700 mb-1">Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required
                className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm"
                placeholder="••••••••" />
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2.5 bg-forest-600 text-white font-semibold rounded-lg hover:bg-forest-700 transition-colors disabled:opacity-60 text-sm">
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>
        <div className="text-center mt-4">
          <Link to="/" className="text-forest-300 text-sm hover:text-white transition-colors">← Back to website</Link>
        </div>
      </div>
    </div>
  );
}

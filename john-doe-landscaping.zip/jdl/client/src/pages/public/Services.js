import { Link } from 'react-router-dom';

const services = [
  { icon: '🌿', title: 'Lawn Mowing & Maintenance', price: 'From $50', features: ['Weekly/bi-weekly mowing', 'Edging & trimming', 'Grass clipping cleanup', 'Lawn health assessment'] },
  { icon: '🌳', title: 'Tree & Hedge Trimming', price: 'From $75', features: ['Hedge shaping', 'Tree branch trimming', 'Shrub maintenance', 'Storm damage cleanup'] },
  { icon: '🌸', title: 'Garden Design & Planting', price: 'From $200', features: ['Custom garden layouts', 'Flower bed installation', 'Seasonal planting', 'Container gardens'] },
  { icon: '🍂', title: 'Seasonal Cleanup', price: 'From $100', features: ['Spring/fall cleanup', 'Leaf removal', 'Mulch application', 'Bed preparation'] },
  { icon: '💧', title: 'Irrigation Services', price: 'From $150', features: ['Sprinkler installation', 'System repair', 'Winterization', 'Drip irrigation'] },
  { icon: '🪨', title: 'Hardscaping', price: 'From $500', features: ['Patio installation', 'Walkways & paths', 'Retaining walls', 'Decorative stone'] },
  { icon: '🌱', title: 'Lawn Treatment', price: 'From $60', features: ['Fertilization', 'Weed control', 'Aeration', 'Overseeding'] },
  { icon: '✨', title: 'Pressure Washing', price: 'From $100', features: ['Driveways', 'Decks & patios', 'Walkways', 'Siding'] },
];

export default function Services() {
  return (
    <div className="fade-in">
      <section className="bg-gradient-to-br from-forest-700 to-forest-900 text-white py-16 sm:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h1 className="text-4xl sm:text-5xl mb-4">Our Services</h1>
          <p className="text-forest-200 max-w-lg text-lg">Comprehensive landscaping solutions for every need and budget.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {services.map(s => (
            <div key={s.title} className="bg-white border border-forest-100 rounded-xl p-6 hover:shadow-lg hover:border-forest-200 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <span className="text-2xl">{s.icon}</span>
                  <h3 className="text-lg text-forest-800 mt-2 font-display">{s.title}</h3>
                </div>
                <span className="text-forest-600 font-semibold text-sm bg-forest-50 px-3 py-1 rounded-full">{s.price}</span>
              </div>
              <ul className="space-y-2">
                {s.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-bark-500">
                    <svg className="w-4 h-4 text-forest-500 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/>
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-bark-50 rounded-2xl p-8 sm:p-12 text-center">
          <h2 className="text-2xl sm:text-3xl text-forest-800 mb-3">Need Something Custom?</h2>
          <p className="text-bark-500 mb-6 max-w-md mx-auto">Every property is different. Let me create a custom plan tailored to your space and budget.</p>
          <Link to="/quote"
            className="inline-block px-8 py-3.5 bg-forest-600 text-white font-semibold rounded-lg hover:bg-forest-700 transition-colors">
            Request a Custom Quote
          </Link>
        </div>
      </section>
    </div>
  );
}

import { Link } from 'react-router-dom';

export default function About() {
  return (
    <div className="fade-in">
      {/* Header */}
      <section className="bg-gradient-to-br from-forest-700 to-forest-900 text-white py-16 sm:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h1 className="text-4xl sm:text-5xl mb-4">About John Doe</h1>
          <p className="text-forest-200 max-w-lg text-lg">Dedicated to making your outdoor spaces beautiful since 2015.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Photo placeholder */}
          <div className="bg-gradient-to-br from-forest-100 to-bark-100 rounded-2xl aspect-[4/3] flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-3">🌿</div>
              <p className="text-bark-400 text-sm">John Doe, Owner</p>
            </div>
          </div>

          <div>
            <h2 className="text-3xl text-forest-800 mb-4">A Personal Touch</h2>
            <div className="space-y-4 text-bark-600 leading-relaxed">
              <p>
                I'm John Doe, the sole owner and operator of JD Landscaping. When you hire me, you get me — not a rotating crew of strangers. I take pride in treating every property like it's my own.
              </p>
              <p>
                After working for large landscaping companies for years, I started my own business to bring back the personal service and attention to detail that big operations often lose. Every job I take is one I can stand behind.
              </p>
              <p>
                From simple weekly mowing to full landscape redesigns, I bring the same level of care and professionalism to every project. My goal is to build lasting relationships with my clients and keep their properties looking their best year-round.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4">
              {[
                ['Licensed & Insured', 'Full liability coverage'],
                ['10+ Years', 'Of experience'],
                ['Local Business', 'Springfield, IL'],
                ['Free Estimates', 'No obligation'],
              ].map(([title, sub]) => (
                <div key={title} className="bg-forest-50 rounded-lg p-4">
                  <div className="font-semibold text-forest-800 text-sm">{title}</div>
                  <div className="text-xs text-bark-400 mt-0.5">{sub}</div>
                </div>
              ))}
            </div>

            <Link to="/quote"
              className="inline-block mt-8 px-6 py-3 bg-forest-600 text-white font-semibold rounded-lg hover:bg-forest-700 transition-colors">
              Get a Free Quote
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

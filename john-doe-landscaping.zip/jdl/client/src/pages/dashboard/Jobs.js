import { useState, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('calendar'); // 'calendar' | 'list'
  const [currentDate, setCurrentDate] = useState(new Date());
  const [filterStatus, setFilterStatus] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (filterStatus) params.set('status', filterStatus);
    if (view === 'calendar') {
      params.set('month', currentDate.getMonth() + 1);
      params.set('year', currentDate.getFullYear());
    }
    api.get(`/jobs?${params}`).then(setJobs).catch(console.error).finally(() => setLoading(false));
  }, [filterStatus, currentDate, view]);

  const statusBadge = (s) => ({
    scheduled: 'bg-blue-100 text-blue-700',
    in_progress: 'bg-amber-100 text-amber-700',
    completed: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700',
  }[s] || 'bg-gray-100 text-gray-700');

  const calendarDays = useMemo(() => {
    const y = currentDate.getFullYear();
    const m = currentDate.getMonth();
    const firstDay = new Date(y, m, 1).getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const days = [];
    for (let i = 0; i < firstDay; i++) days.push(null);
    for (let d = 1; d <= daysInMonth; d++) days.push(d);
    return days;
  }, [currentDate]);

  const jobsByDate = useMemo(() => {
    const map = {};
    jobs.forEach(j => {
      if (!j.scheduled_date) return;
      const d = new Date(j.scheduled_date).getDate();
      if (!map[d]) map[d] = [];
      map[d].push(j);
    });
    return map;
  }, [jobs]);

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));

  const today = new Date();
  const isToday = (day) => day === today.getDate() && currentDate.getMonth() === today.getMonth() && currentDate.getFullYear() === today.getFullYear();

  return (
    <div className="space-y-5 fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl text-forest-800 font-display">Jobs</h1>
          <p className="text-bark-400 text-sm mt-1">Manage your scheduled work</p>
        </div>
        <Link to="/dashboard/jobs/new"
          className="px-5 py-2.5 bg-forest-600 text-white text-sm font-semibold rounded-lg hover:bg-forest-700 transition-colors text-center">
          + New Job
        </Link>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex bg-white border border-bark-100 rounded-lg overflow-hidden">
          {['calendar', 'list'].map(v => (
            <button key={v} onClick={() => setView(v)}
              className={`px-4 py-2 text-sm font-medium transition-colors ${view === v ? 'bg-forest-600 text-white' : 'text-bark-500 hover:bg-bark-50'}`}>
              {v === 'calendar' ? '📅 Calendar' : '📝 List'}
            </button>
          ))}
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="px-3 py-2 text-sm border border-bark-200 rounded-lg bg-white outline-none">
          <option value="">All Statuses</option>
          <option value="scheduled">Scheduled</option>
          <option value="in_progress">In Progress</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      {loading ? (
        <div className="h-64 bg-white rounded-xl border border-bark-100 animate-pulse"></div>
      ) : view === 'calendar' ? (
        /* Calendar View */
        <div className="bg-white rounded-xl border border-bark-100 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-bark-50">
            <button onClick={prevMonth} className="p-2 hover:bg-bark-50 rounded-lg text-bark-500">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M15 19l-7-7 7-7"/></svg>
            </button>
            <h2 className="font-display text-lg text-forest-800">
              {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
            </h2>
            <button onClick={nextMonth} className="p-2 hover:bg-bark-50 rounded-lg text-bark-500">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M9 5l7 7-7 7"/></svg>
            </button>
          </div>

          <div className="grid grid-cols-7 text-center text-xs font-medium text-bark-400 py-2 border-b border-bark-50">
            {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => <div key={d}>{d}</div>)}
          </div>

          <div className="grid grid-cols-7 auto-rows-fr min-h-[400px]">
            {calendarDays.map((day, i) => (
              <div key={i} className={`border-r border-b border-bark-50 p-1 min-h-[60px] sm:min-h-[80px] ${!day ? 'bg-bark-50/30' : 'hover:bg-bark-50/50'} ${isToday(day) ? 'bg-forest-50/50' : ''}`}>
                {day && (
                  <>
                    <div className={`text-xs font-medium mb-0.5 px-1 ${isToday(day) ? 'text-forest-700' : 'text-bark-500'}`}>
                      {day}
                    </div>
                    {(jobsByDate[day] || []).slice(0, 3).map(j => (
                      <Link key={j.id} to={`/dashboard/jobs/${j.id}`}
                        className={`block text-xs px-1.5 py-0.5 rounded mb-0.5 truncate cursor-pointer ${
                          j.status === 'completed' ? 'bg-green-100 text-green-700' :
                          j.status === 'in_progress' ? 'bg-amber-100 text-amber-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>
                        {j.scheduled_time ? j.scheduled_time.slice(0,5) + ' ' : ''}{j.title}
                      </Link>
                    ))}
                    {(jobsByDate[day] || []).length > 3 && (
                      <div className="text-xs text-bark-400 px-1">+{jobsByDate[day].length - 3} more</div>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* List View */
        <div className="bg-white rounded-xl border border-bark-100 overflow-hidden">
          {jobs.length === 0 ? (
            <div className="p-12 text-center text-bark-400">No jobs found</div>
          ) : (
            <div className="divide-y divide-bark-50">
              {jobs.map(job => (
                <Link key={job.id} to={`/dashboard/jobs/${job.id}`}
                  className="flex items-center justify-between p-4 hover:bg-bark-50/50 transition-colors">
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-forest-800">{job.title}</div>
                    <div className="text-xs text-bark-400 mt-0.5">
                      {job.customer_name || 'No customer'} · {job.scheduled_date ? new Date(job.scheduled_date).toLocaleDateString() : 'Unscheduled'}
                      {job.scheduled_time && ` at ${job.scheduled_time.slice(0,5)}`}
                    </div>
                    {job.address && <div className="text-xs text-bark-300 mt-0.5 truncate">📍 {job.address}</div>}
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    {job.price && <span className="text-sm font-medium text-forest-700">${parseFloat(job.price).toFixed(0)}</span>}
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap ${statusBadge(job.status)}`}>
                      {job.status.replace('_', ' ')}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

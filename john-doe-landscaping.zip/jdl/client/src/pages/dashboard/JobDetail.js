import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../../utils/api';

export default function JobDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const [job, setJob] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [form, setForm] = useState({
    customer_id: '', title: '', description: '', address: '',
    status: 'scheduled', scheduled_date: '', scheduled_time: '',
    estimated_duration: '', price: '',
  });

  useEffect(() => {
    api.get('/customers').then(setCustomers).catch(console.error);
    if (!isNew) {
      api.get(`/jobs/${id}`).then(data => {
        setJob(data);
        setForm({
          customer_id: data.customer_id || '',
          title: data.title || '',
          description: data.description || '',
          address: data.address || '',
          status: data.status || 'scheduled',
          scheduled_date: data.scheduled_date ? data.scheduled_date.split('T')[0] : '',
          scheduled_time: data.scheduled_time?.slice(0, 5) || '',
          estimated_duration: data.estimated_duration || '',
          price: data.price || '',
        });
      }).catch(console.error).finally(() => setLoading(false));
    }
  }, [id, isNew]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, customer_id: form.customer_id || null };
      if (isNew) {
        const created = await api.post('/jobs', payload);
        navigate(`/dashboard/jobs/${created.id}`, { replace: true });
      } else {
        const updated = await api.put(`/jobs/${id}`, payload);
        setJob(prev => ({ ...prev, ...updated }));
      }
    } catch (err) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleStatusChange = async (status) => {
    try {
      await api.patch(`/jobs/${id}/status`, { status });
      setForm(f => ({ ...f, status }));
      setJob(j => ({ ...j, status }));
    } catch (err) {
      alert(err.message);
    }
  };

  const handleAddNote = async () => {
    if (!noteText.trim()) return;
    try {
      const note = await api.post(`/jobs/${id}/notes`, { content: noteText });
      setJob(j => ({ ...j, notes: [note, ...(j.notes || [])] }));
      setNoteText('');
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this job?')) return;
    await api.delete(`/jobs/${id}`);
    navigate('/dashboard/jobs');
  };

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  if (loading) return <div className="animate-pulse h-64 bg-bark-100 rounded-xl"></div>;

  return (
    <div className="space-y-5 fade-in max-w-3xl">
      <div className="flex items-center gap-3">
        <Link to="/dashboard/jobs" className="p-2 hover:bg-bark-100 rounded-lg text-bark-400">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M15 19l-7-7 7-7"/></svg>
        </Link>
        <h1 className="text-2xl text-forest-800 font-display">{isNew ? 'New Job' : 'Edit Job'}</h1>
      </div>

      {/* Quick status buttons */}
      {!isNew && (
        <div className="flex flex-wrap gap-2">
          {['scheduled', 'in_progress', 'completed', 'cancelled'].map(s => (
            <button key={s} onClick={() => handleStatusChange(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                form.status === s ? 'ring-2 ring-offset-1 ring-forest-500' : ''
              } ${
                s === 'scheduled' ? 'bg-blue-100 text-blue-700' :
                s === 'in_progress' ? 'bg-amber-100 text-amber-700' :
                s === 'completed' ? 'bg-green-100 text-green-700' :
                'bg-red-100 text-red-700'
              }`}>
              {s.replace('_', ' ')}
            </button>
          ))}
        </div>
      )}

      <form onSubmit={handleSave} className="bg-white rounded-xl border border-bark-100 p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-bark-700 mb-1">Job Title *</label>
          <input name="title" value={form.title} onChange={handleChange} required
            className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="e.g. Weekly Lawn Mowing" />
        </div>

        <div>
          <label className="block text-sm font-medium text-bark-700 mb-1">Customer</label>
          <select name="customer_id" value={form.customer_id} onChange={handleChange}
            className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm bg-white">
            <option value="">No customer</option>
            {customers.map(c => (
              <option key={c.id} value={c.id}>{c.first_name} {c.last_name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-bark-700 mb-1">Address</label>
          <input name="address" value={form.address} onChange={handleChange}
            className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="Job location address" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Date</label>
            <input name="scheduled_date" type="date" value={form.scheduled_date} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Time</label>
            <input name="scheduled_time" type="time" value={form.scheduled_time} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Duration (min)</label>
            <input name="estimated_duration" type="number" value={form.estimated_duration} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="60" />
          </div>
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Price ($)</label>
            <input name="price" type="number" step="0.01" value={form.price} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" placeholder="75.00" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-bark-700 mb-1">Notes</label>
          <textarea name="description" value={form.description} onChange={handleChange} rows={3}
            className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm resize-none" placeholder="Job details..." />
        </div>

        <div className="flex items-center justify-between pt-2">
          <button type="submit" disabled={saving}
            className="px-6 py-2.5 bg-forest-600 text-white text-sm font-semibold rounded-lg hover:bg-forest-700 transition-colors disabled:opacity-60">
            {saving ? 'Saving...' : isNew ? 'Create Job' : 'Save Changes'}
          </button>
          {!isNew && (
            <button type="button" onClick={handleDelete}
              className="px-4 py-2.5 text-red-600 text-sm font-medium hover:bg-red-50 rounded-lg transition-colors">
              Delete
            </button>
          )}
        </div>
      </form>

      {/* Notes section */}
      {!isNew && (
        <div className="bg-white rounded-xl border border-bark-100 p-5">
          <h2 className="font-display text-lg text-forest-800 mb-3">Job Notes</h2>
          <div className="flex gap-2 mb-4">
            <input value={noteText} onChange={e => setNoteText(e.target.value)}
              className="flex-1 px-3 py-2 border border-bark-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-forest-500"
              placeholder="Add a note..." onKeyDown={e => e.key === 'Enter' && handleAddNote()} />
            <button onClick={handleAddNote} className="px-4 py-2 bg-forest-600 text-white text-sm rounded-lg hover:bg-forest-700">Add</button>
          </div>
          <div className="space-y-2">
            {(job?.notes || []).map(n => (
              <div key={n.id} className="p-3 bg-bark-50 rounded-lg text-sm text-bark-600">
                <p>{n.content}</p>
                <div className="text-xs text-bark-400 mt-1">{new Date(n.created_at).toLocaleString()}</div>
              </div>
            ))}
            {(job?.notes || []).length === 0 && <p className="text-sm text-bark-400">No notes yet.</p>}
          </div>
        </div>
      )}
    </div>
  );
}

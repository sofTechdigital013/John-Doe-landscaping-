import { useState, useEffect } from 'react';
import { api } from '../../utils/api';

export default function Quotes() {
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [convertForm, setConvertForm] = useState({ scheduled_date: '', scheduled_time: '', price: '' });

  useEffect(() => {
    const q = filterStatus ? `?status=${filterStatus}` : '';
    api.get(`/quotes${q}`).then(setQuotes).catch(console.error).finally(() => setLoading(false));
  }, [filterStatus]);

  const statusBadge = (s) => ({
    pending: 'bg-amber-100 text-amber-700',
    reviewed: 'bg-blue-100 text-blue-700',
    approved: 'bg-green-100 text-green-700',
    declined: 'bg-red-100 text-red-700',
    converted: 'bg-purple-100 text-purple-700',
  }[s] || 'bg-gray-100 text-gray-700');

  const handleUpdateStatus = async (id, status, estimated_price, admin_notes) => {
    try {
      const updated = await api.put(`/quotes/${id}`, { status, estimated_price, admin_notes });
      setQuotes(qs => qs.map(q => q.id === id ? { ...q, ...updated } : q));
    } catch (err) {
      alert(err.message);
    }
  };

  const handleConvert = async (id) => {
    try {
      await api.post(`/quotes/${id}/convert`, convertForm);
      setQuotes(qs => qs.map(q => q.id === id ? { ...q, status: 'converted' } : q));
      setExpandedId(null);
      setConvertForm({ scheduled_date: '', scheduled_time: '', price: '' });
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this quote?')) return;
    await api.delete(`/quotes/${id}`);
    setQuotes(qs => qs.filter(q => q.id !== id));
  };

  return (
    <div className="space-y-5 fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl text-forest-800 font-display">Quote Requests</h1>
        <p className="text-bark-400 text-sm mt-1">{quotes.length} total quotes</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {['', 'pending', 'reviewed', 'approved', 'converted', 'declined'].map(s => (
          <button key={s} onClick={() => setFilterStatus(s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              filterStatus === s ? 'bg-forest-600 text-white' : 'bg-white border border-bark-200 text-bark-600 hover:bg-bark-50'
            }`}>
            {s || 'All'}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="h-24 bg-bark-100 rounded-xl animate-pulse"></div>)}</div>
      ) : quotes.length === 0 ? (
        <div className="bg-white rounded-xl border border-bark-100 p-12 text-center text-bark-400">No quotes found</div>
      ) : (
        <div className="space-y-3">
          {quotes.map(q => (
            <div key={q.id} className="bg-white rounded-xl border border-bark-100 overflow-hidden">
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium text-forest-800">{q.customer_name}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusBadge(q.status)}`}>
                        {q.status}
                      </span>
                    </div>
                    <div className="text-xs text-bark-400 mt-1">
                      {q.email} {q.phone && `· ${q.phone}`}
                    </div>
                    {q.service_type && <div className="text-xs text-bark-500 mt-1">Service: {q.service_type}</div>}
                    {q.address && <div className="text-xs text-bark-400 mt-0.5">📍 {q.address}</div>}
                    {q.description && <p className="text-sm text-bark-600 mt-2 bg-bark-50 rounded-lg p-3">{q.description}</p>}
                    <div className="text-xs text-bark-300 mt-2">Submitted {new Date(q.created_at).toLocaleDateString()}</div>
                  </div>
                </div>

                {/* Action buttons */}
                {q.status !== 'converted' && (
                  <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-bark-50">
                    {q.status === 'pending' && (
                      <button onClick={() => handleUpdateStatus(q.id, 'reviewed')}
                        className="px-3 py-1.5 bg-blue-50 text-blue-700 text-xs font-medium rounded-lg hover:bg-blue-100">
                        Mark Reviewed
                      </button>
                    )}
                    {['pending', 'reviewed'].includes(q.status) && (
                      <button onClick={() => {
                        setExpandedId(expandedId === q.id ? null : q.id);
                        setConvertForm({ scheduled_date: q.preferred_date?.split('T')[0] || '', scheduled_time: '', price: q.estimated_price || '' });
                      }}
                        className="px-3 py-1.5 bg-green-50 text-green-700 text-xs font-medium rounded-lg hover:bg-green-100">
                        Convert to Job
                      </button>
                    )}
                    {q.status !== 'declined' && (
                      <button onClick={() => handleUpdateStatus(q.id, 'declined')}
                        className="px-3 py-1.5 bg-red-50 text-red-700 text-xs font-medium rounded-lg hover:bg-red-100">
                        Decline
                      </button>
                    )}
                    <button onClick={() => handleDelete(q.id)}
                      className="px-3 py-1.5 text-bark-400 text-xs font-medium hover:text-red-600">
                      Delete
                    </button>
                  </div>
                )}
              </div>

              {/* Convert form */}
              {expandedId === q.id && (
                <div className="p-4 bg-forest-50 border-t border-forest-100">
                  <h3 className="text-sm font-semibold text-forest-800 mb-3">Convert to Job</h3>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs text-bark-500 mb-1">Date</label>
                      <input type="date" value={convertForm.scheduled_date}
                        onChange={e => setConvertForm(f => ({ ...f, scheduled_date: e.target.value }))}
                        className="w-full px-3 py-2 border border-bark-200 rounded-lg text-sm outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs text-bark-500 mb-1">Time</label>
                      <input type="time" value={convertForm.scheduled_time}
                        onChange={e => setConvertForm(f => ({ ...f, scheduled_time: e.target.value }))}
                        className="w-full px-3 py-2 border border-bark-200 rounded-lg text-sm outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs text-bark-500 mb-1">Price ($)</label>
                      <input type="number" step="0.01" value={convertForm.price}
                        onChange={e => setConvertForm(f => ({ ...f, price: e.target.value }))}
                        className="w-full px-3 py-2 border border-bark-200 rounded-lg text-sm outline-none" />
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => handleConvert(q.id)}
                      className="px-4 py-2 bg-forest-600 text-white text-xs font-semibold rounded-lg hover:bg-forest-700">
                      Create Job
                    </button>
                    <button onClick={() => setExpandedId(null)}
                      className="px-4 py-2 text-bark-500 text-xs font-medium hover:text-bark-700">
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

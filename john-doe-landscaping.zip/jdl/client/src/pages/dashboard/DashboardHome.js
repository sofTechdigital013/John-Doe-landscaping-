import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../utils/api';

export default function DashboardHome() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/analytics/dashboard')
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSkeleton />;
  if (!data) return <div className="text-bark-500">Failed to load dashboard data.</div>;

  const statCards = [
    { label: 'Active Jobs', value: data.activeJobs, icon: '📅', color: 'bg-forest-50 text-forest-700', link: '/dashboard/jobs' },
    { label: 'Total Customers', value: data.totalCustomers, icon: '👥', color: 'bg-bark-50 text-bark-700', link: '/dashboard/customers' },
    { label: 'Pending Quotes', value: data.pendingQuotes, icon: '📋', color: 'bg-sand-50 text-sand-700', link: '/dashboard/quotes' },
    { label: 'Revenue', value: `$${data.totalRevenue.toLocaleString()}`, icon: '💰', color: 'bg-forest-50 text-forest-700' },
  ];

  const statusBadge = (s) => {
    const map = {
      scheduled: 'bg-blue-100 text-blue-700',
      in_progress: 'bg-amber-100 text-amber-700',
      completed: 'bg-green-100 text-green-700',
      cancelled: 'bg-red-100 text-red-700',
    };
    return map[s] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl text-forest-800 font-display">Dashboard</h1>
        <p className="text-bark-400 text-sm mt-1">Welcome back, John. Here's your business overview.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {statCards.map(card => (
          <Link key={card.label} to={card.link || '#'}
            className={`${card.color} rounded-xl p-4 sm:p-5 hover:shadow-md transition-all`}>
            <div className="text-2xl mb-2">{card.icon}</div>
            <div className="text-2xl sm:text-3xl font-bold">{card.value}</div>
            <div className="text-sm opacity-70 mt-0.5">{card.label}</div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Jobs */}
        <div className="bg-white rounded-xl border border-bark-100 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-bark-50">
            <h2 className="font-display text-lg text-forest-800">Recent Jobs</h2>
            <Link to="/dashboard/jobs" className="text-xs text-forest-600 font-medium hover:text-forest-800">View all →</Link>
          </div>
          <div className="divide-y divide-bark-50">
            {data.recentJobs.length === 0 ? (
              <div className="p-8 text-center text-bark-400 text-sm">No jobs yet</div>
            ) : data.recentJobs.map(job => (
              <Link key={job.id} to={`/dashboard/jobs/${job.id}`} className="flex items-center justify-between p-4 hover:bg-bark-50/50 transition-colors">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-forest-800 truncate">{job.title}</div>
                  <div className="text-xs text-bark-400 mt-0.5">{job.customer_name || 'No customer'} · {job.scheduled_date ? new Date(job.scheduled_date).toLocaleDateString() : 'Unscheduled'}</div>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap ${statusBadge(job.status)}`}>
                  {job.status.replace('_', ' ')}
                </span>
              </Link>
            ))}
          </div>
        </div>

        {/* Quick actions + monthly revenue */}
        <div className="space-y-5">
          <div className="bg-white rounded-xl border border-bark-100 p-4">
            <h2 className="font-display text-lg text-forest-800 mb-3">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-2">
              {[
                { to: '/dashboard/jobs/new', icon: '➕', label: 'New Job' },
                { to: '/dashboard/customers/new', icon: '👤', label: 'New Customer' },
                { to: '/dashboard/quotes', icon: '📋', label: 'View Quotes' },
                { to: '/dashboard/jobs', icon: '📅', label: 'Calendar' },
              ].map(a => (
                <Link key={a.to} to={a.to}
                  className="flex items-center gap-2 p-3 bg-bark-50 rounded-lg hover:bg-forest-50 transition-colors text-sm font-medium text-bark-700 hover:text-forest-700">
                  <span>{a.icon}</span> {a.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Monthly revenue chart (simple) */}
          <div className="bg-white rounded-xl border border-bark-100 p-4">
            <h2 className="font-display text-lg text-forest-800 mb-3">Monthly Revenue</h2>
            {data.monthlyRevenue.length === 0 ? (
              <p className="text-sm text-bark-400">No completed jobs yet.</p>
            ) : (
              <div className="space-y-2">
                {data.monthlyRevenue.map(m => {
                  const max = Math.max(...data.monthlyRevenue.map(r => parseFloat(r.revenue)));
                  const pct = max > 0 ? (parseFloat(m.revenue) / max) * 100 : 0;
                  return (
                    <div key={m.month} className="flex items-center gap-3">
                      <span className="text-xs text-bark-500 w-16 flex-shrink-0">{m.month}</span>
                      <div className="flex-1 bg-bark-100 rounded-full h-5 overflow-hidden">
                        <div className="h-full bg-forest-500 rounded-full transition-all" style={{ width: `${pct}%` }}></div>
                      </div>
                      <span className="text-xs font-medium text-forest-700 w-16 text-right">${parseFloat(m.revenue).toLocaleString()}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="bg-forest-600 text-white rounded-xl p-4">
            <div className="text-sm font-medium text-forest-200 mb-1">Total Jobs Completed</div>
            <div className="text-3xl font-bold">{data.completedJobs}</div>
            <div className="text-xs text-forest-300 mt-1">out of {data.totalJobs} total jobs</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 bg-bark-100 rounded w-48"></div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <div key={i} className="h-28 bg-bark-100 rounded-xl"></div>)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="h-64 bg-bark-100 rounded-xl"></div>
        <div className="h-64 bg-bark-100 rounded-xl"></div>
      </div>
    </div>
  );
}

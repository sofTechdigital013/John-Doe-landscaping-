import { useState, useEffect } from 'react';
import { api } from '../../utils/api';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/auth/me').then(setUser).catch(console.error).finally(() => setLoading(false));
  }, []);

  const handleGoogleConnect = async () => {
    try {
      const { url } = await api.get('/google/auth-url');
      if (url) window.open(url, '_blank', 'width=500,height=600');
      else alert('Google Calendar is not configured. Add credentials in .env');
    } catch (err) {
      alert('Google Calendar not configured. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to .env');
    }
  };

  const handleGoogleDisconnect = async () => {
    if (!window.confirm('Disconnect Google Calendar?')) return;
    await api.delete('/google/disconnect');
    setUser(u => ({ ...u, google_connected: false }));
  };

  if (loading) return <div className="animate-pulse h-64 bg-bark-100 rounded-xl"></div>;

  return (
    <div className="space-y-5 fade-in max-w-2xl">
      <div>
        <h1 className="text-2xl sm:text-3xl text-forest-800 font-display">Settings</h1>
        <p className="text-bark-400 text-sm mt-1">Manage your account and integrations</p>
      </div>

      {/* Account info */}
      <div className="bg-white rounded-xl border border-bark-100 p-5">
        <h2 className="font-display text-lg text-forest-800 mb-4">Account</h2>
        <div className="space-y-3">
          <div>
            <div className="text-xs text-bark-400 font-medium">Name</div>
            <div className="text-sm text-forest-800">{user?.name || 'John Doe'}</div>
          </div>
          <div>
            <div className="text-xs text-bark-400 font-medium">Email</div>
            <div className="text-sm text-forest-800">{user?.email}</div>
          </div>
        </div>
      </div>

      {/* Google Calendar */}
      <div className="bg-white rounded-xl border border-bark-100 p-5">
        <h2 className="font-display text-lg text-forest-800 mb-2">Google Calendar</h2>
        <p className="text-sm text-bark-400 mb-4">
          Automatically sync your scheduled jobs to Google Calendar so you always know what's next.
        </p>

        {user?.google_connected ? (
          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              <span className="text-sm text-green-700 font-medium">Connected</span>
            </div>
            <button onClick={handleGoogleDisconnect}
              className="text-xs text-red-600 font-medium hover:text-red-800">
              Disconnect
            </button>
          </div>
        ) : (
          <button onClick={handleGoogleConnect}
            className="px-5 py-2.5 bg-white border border-bark-200 rounded-lg text-sm font-medium text-bark-700 hover:bg-bark-50 transition-colors flex items-center gap-2">
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Connect Google Calendar
          </button>
        )}
      </div>

      {/* Notifications */}
      <div className="bg-white rounded-xl border border-bark-100 p-5">
        <h2 className="font-display text-lg text-forest-800 mb-2">Email Notifications</h2>
        <p className="text-sm text-bark-400 mb-4">
          Configure SMTP settings in your .env file to enable automated emails.
        </p>
        <div className="space-y-2 text-sm text-bark-600">
          <div className="flex items-center gap-2 p-2 bg-bark-50 rounded-lg">
            <span>📧</span> Quote confirmation emails to customers
          </div>
          <div className="flex items-center gap-2 p-2 bg-bark-50 rounded-lg">
            <span>⏰</span> Job reminder emails to customers
          </div>
        </div>
      </div>

      {/* Environment info */}
      <div className="bg-bark-50 rounded-xl border border-bark-100 p-5">
        <h2 className="font-display text-lg text-forest-800 mb-2">Setup Checklist</h2>
        <div className="space-y-2">
          {[
            { label: 'PostgreSQL Database', done: true },
            { label: 'Owner Account', done: true },
            { label: 'SMTP Email', done: false, hint: 'Set SMTP_HOST in .env' },
            { label: 'Google Calendar', done: user?.google_connected, hint: 'Set GOOGLE_CLIENT_ID in .env' },
          ].map(item => (
            <div key={item.label} className="flex items-center gap-2 text-sm">
              <span className={item.done ? 'text-green-500' : 'text-bark-300'}>{item.done ? '✅' : '⬜'}</span>
              <span className={item.done ? 'text-forest-700' : 'text-bark-500'}>{item.label}</span>
              {!item.done && item.hint && <span className="text-xs text-bark-400">({item.hint})</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

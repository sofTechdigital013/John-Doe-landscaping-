import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../utils/api';

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    api.get(`/customers${q}`).then(setCustomers).catch(console.error).finally(() => setLoading(false));
  }, [search]);

  return (
    <div className="space-y-5 fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl text-forest-800 font-display">Customers</h1>
          <p className="text-bark-400 text-sm mt-1">{customers.length} total customers</p>
        </div>
        <Link to="/dashboard/customers/new"
          className="px-5 py-2.5 bg-forest-600 text-white text-sm font-semibold rounded-lg hover:bg-forest-700 transition-colors text-center">
          + New Customer
        </Link>
      </div>

      <div className="relative">
        <svg className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-bark-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
          <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 border border-bark-200 rounded-lg bg-white text-sm outline-none focus:ring-2 focus:ring-forest-500"
          placeholder="Search customers..." />
      </div>

      {loading ? (
        <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-bark-100 rounded-lg animate-pulse"></div>)}</div>
      ) : customers.length === 0 ? (
        <div className="bg-white rounded-xl border border-bark-100 p-12 text-center text-bark-400">
          {search ? 'No customers match your search' : 'No customers yet'}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-bark-100 overflow-hidden">
          <div className="divide-y divide-bark-50">
            {customers.map(c => (
              <Link key={c.id} to={`/dashboard/customers/${c.id}`}
                className="flex items-center justify-between p-4 hover:bg-bark-50/50 transition-colors">
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium text-forest-800">{c.first_name} {c.last_name}</div>
                  <div className="text-xs text-bark-400 mt-0.5 space-x-2">
                    {c.email && <span>{c.email}</span>}
                    {c.phone && <span>· {c.phone}</span>}
                  </div>
                  {c.address && <div className="text-xs text-bark-300 mt-0.5 truncate">📍 {c.address}{c.city ? `, ${c.city}` : ''}</div>}
                </div>
                <div className="flex items-center gap-3 ml-3">
                  <div className="text-right hidden sm:block">
                    <div className="text-xs text-bark-400">{c.job_count || 0} jobs</div>
                    <div className="text-xs font-medium text-forest-600">${parseFloat(c.total_revenue || 0).toLocaleString()}</div>
                  </div>
                  <svg className="w-4 h-4 text-bark-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M9 5l7 7-7 7"/></svg>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../../utils/api';

export default function CustomerDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [form, setForm] = useState({
    first_name: '', last_name: '', email: '', phone: '',
    address: '', city: '', state: '', zip: '',
  });

  useEffect(() => {
    if (!isNew) {
      api.get(`/customers/${id}`).then(data => {
        setCustomer(data);
        setForm({
          first_name: data.first_name || '', last_name: data.last_name || '',
          email: data.email || '', phone: data.phone || '',
          address: data.address || '', city: data.city || '',
          state: data.state || '', zip: data.zip || '',
        });
      }).catch(console.error).finally(() => setLoading(false));
    }
  }, [id, isNew]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (isNew) {
        const created = await api.post('/customers', form);
        navigate(`/dashboard/customers/${created.id}`, { replace: true });
      } else {
        const updated = await api.put(`/customers/${id}`, form);
        setCustomer(prev => ({ ...prev, ...updated }));
      }
    } catch (err) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleAddNote = async () => {
    if (!noteText.trim()) return;
    try {
      const note = await api.post(`/customers/${id}/notes`, { content: noteText });
      setCustomer(c => ({ ...c, notes: [note, ...(c.notes || [])] }));
      setNoteText('');
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this customer and all their data?')) return;
    await api.delete(`/customers/${id}`);
    navigate('/dashboard/customers');
  };

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const statusBadge = (s) => ({
    scheduled: 'bg-blue-100 text-blue-700',
    in_progress: 'bg-amber-100 text-amber-700',
    completed: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700',
  }[s] || 'bg-gray-100 text-gray-700');

  if (loading) return <div className="animate-pulse h-64 bg-bark-100 rounded-xl"></div>;

  return (
    <div className="space-y-5 fade-in max-w-3xl">
      <div className="flex items-center gap-3">
        <Link to="/dashboard/customers" className="p-2 hover:bg-bark-100 rounded-lg text-bark-400">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M15 19l-7-7 7-7"/></svg>
        </Link>
        <h1 className="text-2xl text-forest-800 font-display">{isNew ? 'New Customer' : `${form.first_name} ${form.last_name}`}</h1>
      </div>

      <form onSubmit={handleSave} className="bg-white rounded-xl border border-bark-100 p-5 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">First Name *</label>
            <input name="first_name" value={form.first_name} onChange={handleChange} required
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Last Name *</label>
            <input name="last_name" value={form.last_name} onChange={handleChange} required
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Email</label>
            <input name="email" type="email" value={form.email} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">Phone</label>
            <input name="phone" value={form.phone} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-bark-700 mb-1">Address</label>
          <input name="address" value={form.address} onChange={handleChange}
            className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">City</label>
            <input name="city" value={form.city} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">State</label>
            <input name="state" value={form.state} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-bark-700 mb-1">ZIP</label>
            <input name="zip" value={form.zip} onChange={handleChange}
              className="w-full px-4 py-2.5 border border-bark-200 rounded-lg focus:ring-2 focus:ring-forest-500 focus:border-forest-500 outline-none text-sm" />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <button type="submit" disabled={saving}
            className="px-6 py-2.5 bg-forest-600 text-white text-sm font-semibold rounded-lg hover:bg-forest-700 transition-colors disabled:opacity-60">
            {saving ? 'Saving...' : isNew ? 'Create Customer' : 'Save Changes'}
          </button>
          {!isNew && (
            <button type="button" onClick={handleDelete}
              className="px-4 py-2.5 text-red-600 text-sm font-medium hover:bg-red-50 rounded-lg transition-colors">
              Delete
            </button>
          )}
        </div>
      </form>

      {/* Job history */}
      {!isNew && customer?.jobs && (
        <div className="bg-white rounded-xl border border-bark-100 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-bark-50">
            <h2 className="font-display text-lg text-forest-800">Job History</h2>
            <Link to={`/dashboard/jobs/new`} className="text-xs text-forest-600 font-medium">+ New Job</Link>
          </div>
          {customer.jobs.length === 0 ? (
            <div className="p-8 text-center text-bark-400 text-sm">No jobs yet</div>
          ) : (
            <div className="divide-y divide-bark-50">
              {customer.jobs.map(j => (
                <Link key={j.id} to={`/dashboard/jobs/${j.id}`} className="flex items-center justify-between p-4 hover:bg-bark-50/50">
                  <div>
                    <div className="text-sm font-medium text-forest-800">{j.title}</div>
                    <div className="text-xs text-bark-400">{j.scheduled_date ? new Date(j.scheduled_date).toLocaleDateString() : 'Unscheduled'}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    {j.price && <span className="text-sm font-medium text-forest-700">${parseFloat(j.price).toFixed(0)}</span>}
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusBadge(j.status)}`}>
                      {j.status.replace('_', ' ')}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Notes */}
      {!isNew && (
        <div className="bg-white rounded-xl border border-bark-100 p-5">
          <h2 className="font-display text-lg text-forest-800 mb-3">Notes</h2>
          <div className="flex gap-2 mb-4">
            <input value={noteText} onChange={e => setNoteText(e.target.value)}
              className="flex-1 px-3 py-2 border border-bark-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-forest-500"
              placeholder="Add a note..." onKeyDown={e => e.key === 'Enter' && handleAddNote()} />
            <button onClick={handleAddNote} className="px-4 py-2 bg-forest-600 text-white text-sm rounded-lg hover:bg-forest-700">Add</button>
          </div>
          <div className="space-y-2">
            {(customer?.notes || []).map(n => (
              <div key={n.id} className="p-3 bg-bark-50 rounded-lg text-sm text-bark-600">
                <p>{n.content}</p>
                <div className="text-xs text-bark-400 mt-1">{new Date(n.created_at).toLocaleString()}</div>
              </div>
            ))}
            {(customer?.notes || []).length === 0 && <p className="text-sm text-bark-400">No notes yet.</p>}
          </div>
        </div>
      )}
    </div>
  );
}

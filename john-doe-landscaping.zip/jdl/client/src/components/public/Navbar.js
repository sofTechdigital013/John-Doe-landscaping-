import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  const isActive = (p) => loc.pathname === p;

  const links = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About' },
    { to: '/services', label: 'Services' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <nav className="bg-white/95 backdrop-blur-md border-b border-forest-100 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 bg-forest-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 3c-1.5 3-4 5-7 6 1 2 2 5 2 8h10c0-3 1-6 2-8-3-1-5.5-3-7-6z"/>
                <path d="M12 21v-8"/>
              </svg>
            </div>
            <span className="font-display text-lg sm:text-xl text-forest-800">JD Landscaping</span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {links.map(l => (
              <Link key={l.to} to={l.to}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive(l.to) ? 'bg-forest-50 text-forest-700' : 'text-bark-700 hover:text-forest-700 hover:bg-forest-50/50'
                }`}>
                {l.label}
              </Link>
            ))}
            <Link to="/quote"
              className="ml-3 px-5 py-2.5 bg-forest-600 text-white text-sm font-semibold rounded-lg hover:bg-forest-700 transition-colors shadow-sm">
              Get a Quote
            </Link>
          </div>

          {/* Mobile menu button */}
          <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-lg hover:bg-forest-50">
            <svg className="w-6 h-6 text-forest-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              {open ? <path d="M6 18L18 6M6 6l12 12"/> : <path d="M4 6h16M4 12h16M4 18h16"/>}
            </svg>
          </button>
        </div>

        {/* Mobile nav */}
        {open && (
          <div className="md:hidden pb-4 fade-in">
            {links.map(l => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)}
                className={`block px-4 py-3 rounded-lg text-sm font-medium ${
                  isActive(l.to) ? 'bg-forest-50 text-forest-700' : 'text-bark-700'
                }`}>
                {l.label}
              </Link>
            ))}
            <Link to="/quote" onClick={() => setOpen(false)}
              className="block mt-2 px-4 py-3 bg-forest-600 text-white text-center text-sm font-semibold rounded-lg">
              Get a Quote
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}

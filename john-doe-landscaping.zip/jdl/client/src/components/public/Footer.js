import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-forest-900 text-forest-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
          <div>
            <h3 className="text-white text-xl mb-3">JD Landscaping</h3>
            <p className="text-sm text-forest-300 leading-relaxed">
              Professional landscaping services for residential and commercial properties. Quality work you can trust.
            </p>
          </div>
          <div>
            <h4 className="text-white font-body font-semibold mb-3 text-sm uppercase tracking-wider">Quick Links</h4>
            <div className="space-y-2">
              {['/', '/about', '/services', '/contact', '/quote'].map(p => (
                <Link key={p} to={p}
                  className="block text-sm text-forest-300 hover:text-white transition-colors">
                  {p === '/' ? 'Home' : p.slice(1).charAt(0).toUpperCase() + p.slice(2)}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-white font-body font-semibold mb-3 text-sm uppercase tracking-wider">Contact</h4>
            <div className="space-y-2 text-sm text-forest-300">
              <p>Springfield, IL</p>
              <p>(555) 123-4567</p>
              <p>john@johndoelandscaping.com</p>
            </div>
          </div>
        </div>
        <div className="border-t border-forest-800 mt-8 pt-6 text-center text-xs text-forest-400">
          &copy; {new Date().getFullYear()} John Doe Landscaping. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

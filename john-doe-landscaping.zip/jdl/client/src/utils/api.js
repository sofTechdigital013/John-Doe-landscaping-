const API_BASE = process.env.NODE_ENV === 'production' ? '/api' : 'http://localhost:5000/api';

function getHeaders() {
  const token = localStorage.getItem('jdl_token');
  const h = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
}

async function request(method, path, body = null) {
  const opts = { method, headers: getHeaders() };
  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(`${API_BASE}${path}`, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
  put: (path, body) => request('PUT', path, body),
  patch: (path, body) => request('PATCH', path, body),
  delete: (path) => request('DELETE', path),
};

export function setToken(token) {
  if (token) localStorage.setItem('jdl_token', token);
  else localStorage.removeItem('jdl_token');
}

export function getToken() {
  return localStorage.getItem('jdl_token');
}
